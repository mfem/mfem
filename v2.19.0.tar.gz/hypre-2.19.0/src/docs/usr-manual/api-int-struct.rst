.. Copyright 1998-2019 Lawrence Livermore National Security, LLC and other
   HYPRE Project Developers. See the top-level COPYRIGHT file for details.

   SPDX-License-Identifier: (Apache-2.0 OR MIT)


.. _sec-Struct-System-Interface:

Struct System Interface
==============================================================================

.. doxygengroup:: StructSystemInterface
   :project: hypre


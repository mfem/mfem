# Release 1.0.2

## Major Features and Improvements

## Backwards-Incompatible Changes 

## Bug Fixes and Other Changes

[17](https://github.com/gslib/gslib/issues/17)

## Thanks to our Contributors
This release contains contributions from: @stgeke 
We are also grateful to all who filed issues or helped resolve them, asked and answered questions, and were part of inspiring discussions.
